<?php
namespace App\Controller ;

use App\Entity\News;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;

use App\Service\NewsService as ServiceNews;


class NewsController extends AbstractController {

    /**
     * @Route("/news", name="news_list")
     * @Method ({"GET"})
     */
    public function news(){

        $news  = new ServiceNews($this->getDoctrine()->getManager(),News::class);
        $news = $news->getAllnews();
        return $this->render('news/index.html.twig', array
        ('news' => $news));
    }

    /**
     * @Route ("/news/new", name="new_news")
     * Method ({"GET", "POST"})
     */
    public function new(Request $request){
        $news = new News();

        $form = $this->createFormBuilder($news)
            ->add('title', TextType::class, array('attr' =>array('class' => 'form-control')))
            ->add('description', TextareaType::class, array('required' =>false,
                'attr' =>array('class' =>'form-control')))
            ->add('save', SubmitType::class, array(
                'label' =>'Create',
                'attr' =>array('class'=>'btn btn-primary mt-3')
            ))
            ->getForm();

        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()){
            $news = $form->getData();

            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($news);
            $entityManager->flush();

            return $this->redirectToRoute('news_list');
        }

        return $this->render('news/new.html.twig',array(
            'form'=>$form->createView()
        ));
    }

    /**
     * @Route ("/news/{id}", name= "news_show")
     * @Method ({"GET"})
     */

    public function show($id){
        $news  = new ServiceNews($this->getDoctrine()->getManager(),News::class);
        $news = $news->getNews($id);
        return $this->render('news/show.html.twig', array('news' =>$news));

    }

    /**
     * @Route ("/news/update/{id}", name="update_news")
     * Method ({"GET", "POST"})
     */

    public function update(Request $request, $id){

        $news = $this->getDoctrine()->getRepository(News::class)->find($id);

        $form = $this->createFormBuilder($news)
            ->add('title', TextType::class, array('attr' =>array('class' => 'form-control')))
            ->add('description', TextareaType::class, array('required' =>false,
                'attr' =>array('class' =>'form-control')))
            ->add('save', SubmitType::class, array(
                'label' =>'Update',
                'attr' =>array('class'=>'btn btn-primary mt-3')
            ))
            ->getForm();

        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()){ 	
			$entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($news);
            $entityManager->flush();
            return $this->redirectToRoute('news_list');
        }

        return $this->render('news/update.html.twig',array(
            'form'=>$form->createView()
        ));
    }

    /**
     * @Route ("/news/delete/{id}")
     * @Method ({"DELETE"})
     */

    public function delete(Request $request, $id){

        $news  = new ServiceNews($this->getDoctrine()->getManager(),News::class);
        $news->deleteNews($id);

        return $this->redirectToRoute('news_list');
    }
}

