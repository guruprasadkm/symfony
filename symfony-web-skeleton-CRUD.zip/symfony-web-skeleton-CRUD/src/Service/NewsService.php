<?php 

namespace App\Service;

use Doctrine\ORM\EntityManager;


class NewsService extends AbstractService
{

    public function __construct(EntityManager $em, $entityName)
    {
        $this->em = $em;
        $this->model = $em->getRepository($entityName);
    }

    public function getModel()
    {
        return $this->model;
    }

    public function getNews($news_id)
    {
        return $this->find($news_id);
    }

    public function getAllNews()
    {
        return $this->findAll();
    }

    public function addNews($news_id=null)
    { 
		ob_start();
		if(isset($news_id))
			$model = $this->getModel();
		else 
			$model = null;		

        return $this->save($model);
    }

    public function deleteNews($id)
    {   
        return $this->delete($this->find($id));
    }



}