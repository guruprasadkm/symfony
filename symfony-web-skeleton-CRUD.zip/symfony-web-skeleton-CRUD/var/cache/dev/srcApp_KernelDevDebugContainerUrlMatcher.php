<?php

use Symfony\Component\Routing\Matcher\Dumper\PhpMatcherTrait;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class srcApp_KernelDevDebugContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    use PhpMatcherTrait;

    public function __construct(RequestContext $context)
    {
        $this->context = $context;
        $this->staticRoutes = array(
            '/article' => array(array(array('_route' => 'article_list', '_controller' => 'App\\Controller\\ArticleController::article'), null, null, null, false, false, null)),
            '/article/new' => array(array(array('_route' => 'new_article', '_controller' => 'App\\Controller\\ArticleController::new'), null, null, null, false, false, null)),
            '/contact' => array(array(array('_route' => 'contact', '_controller' => 'App\\Controller\\ContactController::contact'), null, null, null, false, false, null)),
            '/news' => array(array(array('_route' => 'news_list', '_controller' => 'App\\Controller\\NewsController::news'), null, null, null, false, false, null)),
            '/news/new' => array(array(array('_route' => 'new_news', '_controller' => 'App\\Controller\\NewsController::new'), null, null, null, false, false, null)),
            '/welcome' => array(array(array('_route' => 'welcome', '_controller' => 'App\\Controller\\WelcomeController::index'), null, null, null, false, false, null)),
            '/_profiler' => array(array(array('_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'), null, null, null, true, false, null)),
            '/_profiler/search' => array(array(array('_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'), null, null, null, false, false, null)),
            '/_profiler/search_bar' => array(array(array('_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'), null, null, null, false, false, null)),
            '/_profiler/phpinfo' => array(array(array('_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'), null, null, null, false, false, null)),
            '/_profiler/open' => array(array(array('_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'), null, null, null, false, false, null)),
            '/' => array(array(array('_route' => 'hello_page', 'template' => 'hello_page.html.twig', '_controller' => 'Symfony\\Bundle\\FrameworkBundle\\Controller\\TemplateController::templateAction'), null, null, null, false, false, null)),
        );
        $this->regexpList = array(
            0 => '{^(?'
                    .'|/article/(?'
                        .'|([^/]++)(*:27)'
                        .'|update/([^/]++)(*:49)'
                        .'|delete/([^/]++)(*:71)'
                    .')'
                    .'|/news/(?'
                        .'|([^/]++)(*:96)'
                        .'|update/([^/]++)(*:118)'
                        .'|delete/([^/]++)(*:141)'
                    .')'
                    .'|/_(?'
                        .'|error/(\\d+)(?:\\.([^/]++))?(*:181)'
                        .'|wdt/([^/]++)(*:201)'
                        .'|profiler/([^/]++)(?'
                            .'|/(?'
                                .'|search/results(*:247)'
                                .'|router(*:261)'
                                .'|exception(?'
                                    .'|(*:281)'
                                    .'|\\.css(*:294)'
                                .')'
                            .')'
                            .'|(*:304)'
                        .')'
                    .')'
                .')/?$}sD',
        );
        $this->dynamicRoutes = array(
            27 => array(array(array('_route' => 'article_show', '_controller' => 'App\\Controller\\ArticleController::show'), array('id'), null, null, false, true, null)),
            49 => array(array(array('_route' => 'update_article', '_controller' => 'App\\Controller\\ArticleController::update'), array('id'), null, null, false, true, null)),
            71 => array(array(array('_route' => 'app_article_delete', '_controller' => 'App\\Controller\\ArticleController::delete'), array('id'), null, null, false, true, null)),
            96 => array(array(array('_route' => 'news_show', '_controller' => 'App\\Controller\\NewsController::show'), array('id'), null, null, false, true, null)),
            118 => array(array(array('_route' => 'update_news', '_controller' => 'App\\Controller\\NewsController::update'), array('id'), null, null, false, true, null)),
            141 => array(array(array('_route' => 'app_news_delete', '_controller' => 'App\\Controller\\NewsController::delete'), array('id'), null, null, false, true, null)),
            181 => array(array(array('_route' => '_twig_error_test', '_controller' => 'twig.controller.preview_error::previewErrorPageAction', '_format' => 'html'), array('code', '_format'), null, null, false, true, null)),
            201 => array(array(array('_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'), array('token'), null, null, false, true, null)),
            247 => array(array(array('_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'), array('token'), null, null, false, false, null)),
            261 => array(array(array('_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'), array('token'), null, null, false, false, null)),
            281 => array(array(array('_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception::showAction'), array('token'), null, null, false, false, null)),
            294 => array(array(array('_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception::cssAction'), array('token'), null, null, false, false, null)),
            304 => array(array(array('_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'), array('token'), null, null, false, true, null)),
        );
    }
}
